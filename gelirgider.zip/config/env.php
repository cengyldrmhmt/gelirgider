<?php
// Ortam değişkenleri için örnek yapı
return [
    'DB_HOST' => 'localhost',
    'DB_NAME' => 'gelirgider',
    'DB_USER' => 'root',
    'DB_PASS' => '',
    'APP_ENV' => 'local',
    'APP_DEBUG' => true,
    'APP_URL' => 'http://localhost/gelirgider/public',
]; 